from enum import Enum


class ELKA_920_to_924MHz(Enum):
    _920_75f = 0
    _921_25f = 1
    _921_75f = 2
    _922_25f = 3
    _922_75f = 4
    _923_25f = 5