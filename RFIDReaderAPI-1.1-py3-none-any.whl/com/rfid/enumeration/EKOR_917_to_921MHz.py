from enum import Enum


class EKOR_917_to_921MHz(Enum):
    _917_3f = 0
    _917_9f = 1
    _918_5f = 2
    _919_1f = 3
    _919_7f = 4
    _920_3f = 5