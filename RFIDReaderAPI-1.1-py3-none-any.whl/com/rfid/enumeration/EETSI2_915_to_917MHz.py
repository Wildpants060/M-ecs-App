from enum import Enum


class EETSI2_915_to_917MHz(Enum):
    _915_5f = 0
    _915_9f = 1
    _916_3f = 2
    _916_7f = 3