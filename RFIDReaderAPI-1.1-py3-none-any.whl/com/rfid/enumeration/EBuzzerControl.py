from enum import Enum

# 蜂鸣器类型
class EBuzzerControl(Enum):
    ReaderControl = 0
    PCControl = 1