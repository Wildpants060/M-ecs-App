from enum import Enum

#   波特率枚举
class EBaudrate(Enum):
    _9600bps = 0
    _19200bps = 1
    _115200bps = 2
    _230400bps = 3
    _460800bps = 4
    _57600 = 5