from enum import Enum


class EJP_916_to_921MHz(Enum):
    _916_8f = 0
    _918_0f = 1
    _919_2f = 2
    _920_4f = 3