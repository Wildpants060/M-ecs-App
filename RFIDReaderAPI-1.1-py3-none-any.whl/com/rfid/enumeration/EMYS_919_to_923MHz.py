from enum import Enum

class EMYS_919_to_923MHz(Enum):
    _919_25f = 0
    _919_75f = 1
    _920_25f = 2
    _920_75f = 3
    _921_25f = 4
    _921_75f = 5
    _922_25f = 6
    _922_75f = 7