from enum import Enum

# 输出数据格式
class EOutputFormat(Enum):
    Hex = 0
    ASCII = 1
    Decimal = 2