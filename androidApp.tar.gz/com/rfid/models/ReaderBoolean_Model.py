

# 通用 传递布尔类型对象
class ReaderBoolean_Model:
    def __init__(self,fg):
        self.flag = fg
