

class CallBack_Model:
    def __init__(self):
        self._CallBackType = None
        self._CallBackParam = None