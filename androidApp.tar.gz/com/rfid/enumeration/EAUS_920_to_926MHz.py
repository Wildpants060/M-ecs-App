from enum import Enum


class EAUS_920_to_926MHz(Enum):
    _920_25f  = 0
    _920_75f = 1
    _921_25f = 2
    _921_75f = 3
    _922_25f = 4
    _922_75f = 5
    _923_25f = 6
    _923_75f = 7
    _924_25f = 8
    _924_75f = 9