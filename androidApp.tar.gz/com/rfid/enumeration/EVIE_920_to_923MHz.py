from enum import Enum


class EVIE_920_to_923MHz(Enum):
    _920_25f = 0
    _920_75f = 1
    _921_25f = 2
    _921_75f = 3
    _922_25f = 4
    _922_75f = 5