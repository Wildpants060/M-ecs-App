from enum import Enum


class EWiegandSwitch(Enum):
    Close = 0
    Open = 1