from enum import Enum


class ERUS_866_to_867MHz(Enum):
    _866_6f = 0
    _866_8f = 1
    _867_0f = 2  
    _867_2f = 3
    _867_4f = 4