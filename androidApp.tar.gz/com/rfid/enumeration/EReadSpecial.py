from enum import Enum

# 读取特殊区
class EReadSpecial(Enum):
    NXP_BrandID = 0
    NXP_EAS_Alarm = 1
