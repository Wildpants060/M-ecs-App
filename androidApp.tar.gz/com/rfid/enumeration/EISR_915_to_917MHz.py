from enum import Enum


class EISR_915_to_917MHz(Enum):
    _916_25f = 0